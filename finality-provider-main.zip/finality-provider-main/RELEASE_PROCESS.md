# Release Process

Finality-provider repository follows the same release process rules as
[Babylon node](https://github.com/babylonlabs-io/babylon/blob/main/RELEASE_PROCESS.md)
repository.
