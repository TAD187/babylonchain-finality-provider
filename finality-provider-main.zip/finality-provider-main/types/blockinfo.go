package types

type BlockInfo struct {
	Height    uint64
	Hash      []byte
	Finalized bool
}
